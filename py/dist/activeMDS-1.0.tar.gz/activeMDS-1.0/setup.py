from distutils.core import setup
setup(name='activeMDS',
      version='1.0',
      py_modules=['activeMDS'],
      )